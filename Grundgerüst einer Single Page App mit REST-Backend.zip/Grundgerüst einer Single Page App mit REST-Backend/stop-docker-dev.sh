#! /bin/sh
unset API_URL
docker-compose -f docker-compose.dev.yml down
